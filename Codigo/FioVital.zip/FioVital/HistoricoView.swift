//
//  HistoricoView.swift
//  FioVital
//
//  Created by Turma02-26 on 08/04/25.
//

import SwiftUI

struct HistoricoView: View {
    @StateObject var model = information()
    var body: some View {
        ZStack{
            Color.background
                .ignoresSafeArea()
            VStack{
                ForEach(dataUnica(), id: \.self){ registro in
                    //Text(model.arraydigi.last?.id ?? "")
                        //.overlay(RoundedRectangle(cornerRadius: 5)
                            //.stroke(Color.black, lineWidth: 5))
                    Text(registro)
                }
                //Text(model.arraydigi.last?.id ?? "")
                    //.overlay(RoundedRectangle(cornerRadius: 5)
                        //.stroke(Color.black, lineWidth: 5))
            }
        }
        .onAppear(){
            model.fetch()
        }
    }
    func dataUnica() -> [String] {
        var datas:[String] = []
        for registro in model.arraydigi{
            if(!datas.contains(registro.data)){
                datas.append(registro.data)
            }
        }
        return datas
    }
}

#Preview {
    HistoricoView()
}
