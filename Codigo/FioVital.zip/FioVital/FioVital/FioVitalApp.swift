//
//  FioVitalApp.swift
//  FioVital
//
//  Created by Turma02-26 on 04/04/25.
//

import SwiftUI

@main
struct FioVitalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
